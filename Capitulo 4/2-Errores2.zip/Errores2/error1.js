cambiarTriste=function(){
    let cmpImagen;
    cmpImagen=document.getElementById("imgEmoji");
    cmpImagen.src="triste.png";
}