cambiarFeliz=function(){
    let cmpImagen;
    cmpImagen=document.getelementById("imgEmoji");
    cmpImagen.src="feliz.jpg";
}

cambiarCansado=function(){
    let cmpImagen;
    cmpImagen=document.getElementById("imgEmogi");
    cmpImagen.src="cansado.png";
}