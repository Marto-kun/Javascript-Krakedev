cambiarFeliz=function(){
    let cmpMensaje;
    cmpMensaje=document.getElementById("txtEmoji");
    cmpMensaje.src="FELIZ";
}

cambiarCansado=function(){
    let cmpMensaje;
    cmpMensaje=document.getElementById("txtEmoji");
    cmpImagen.innerText="CANSADO";
}