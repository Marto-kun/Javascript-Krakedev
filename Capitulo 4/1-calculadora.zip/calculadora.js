sumar=function(){
    
    //1.Recuperar el valor de la primera caja de texto
    
    //2.Recuperar el valor de la segunda caja de texto
    
    //3.Sumar los dos valores
   
    //4.Mostrar el valor en pantalla
    
}
